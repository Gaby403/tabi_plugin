<?php
if (!defined('ABSPATH')) exit;

$text   = get_option('tabi_popup_text', 'Your popup text');
$button     = get_option('tabi_popup_button', 'Click here');
$button_url = get_option('tabi_popup_button_url', '#');
$bg_color   = get_option('tabi_popup_bg_color', '#b8a999');
$position   = get_option('tabi_popup_position', 'center');
$width_option = get_option('tabi_popup_width', 'default');

$text_tag_option = get_option('tabi_popup_text_tag', 'p');
$font_color  = get_option('tabi_popup_font_color', '#000000');
$font_family = get_option('tabi_popup_font_family', 'sans-serif');
$font_size   = get_option('tabi_popup_font_size', 16);
$font_style  = get_option('tabi_popup_font_style', 'normal');

// Ensure a valid color if the option is empty in the database
if (empty($bg_color)) {
    $bg_color = '#b8a999';
}

// Sanitize the text tag
$allowed_tags = ['p', 'h1', 'h2', 'h3'];
$text_tag = in_array($text_tag_option, $allowed_tags) ? $text_tag_option : 'p';

// Build the inline style string for the text
$text_styles = [
    'color'        => sanitize_hex_color($font_color),
    'font-family'  => esc_attr($font_family),
    'font-size'    => intval($font_size) . 'px',
    'font-style'   => esc_attr($font_style),
];
$style_attr = '';
foreach ($text_styles as $prop => $value) {
    $style_attr .= sprintf('%s: %s; ', $prop, $value);
}

$position_class = ($position === 'bottom') ? 'tabi-popup-bottom' : 'tabi-popup-center';
$width_class = ($width_option === 'full') ? 'tabi-popup-full' : '';
?>

<style>
    .tabi-popup-overlay.tabi-popup-center {
        align-items: center;
        justify-content: center;
    }
    .tabi-popup-overlay.tabi-popup-bottom {
        align-items: flex-end;
        justify-content: center;
    }

    /* Base Animation */
    .tabi-popup-content {
        opacity: 0;
        transition: all 0.5s cubic-bezier(0.25, 0.8, 0.25, 1);
        transform: translateY(20px); /* Slight movement towards center */
    }

    .tabi-popup-overlay.tabi-popup-bottom .tabi-popup-content {
        margin-bottom: 20px;
        transform: translateY(100%); /* Slide from bottom */
    }
    
    .tabi-popup-content.tabi-popup-full {
        width: 100%;
        max-width: 100%;
        border-radius: 0;
        box-sizing: border-box;
    }
    .tabi-popup-overlay.tabi-popup-bottom .tabi-popup-content.tabi-popup-full {
        margin-bottom: 0;
    }

    .tabi-popup-overlay.active .tabi-popup-content {
        opacity: 1;
        transform: translateY(0);
    }
</style>
<div id="tabi-popup-overlay" class="tabi-popup-overlay <?php echo esc_attr($position_class); ?>" style="display:none;">
    <div class="tabi-popup-content <?php echo esc_attr($width_class); ?>" style="background-color: <?php echo esc_attr($bg_color); ?>;">
        <span class="tabi-popup-close">&times;</span>
        <div class="tabi-popup-body">
            <?php printf('<%s style="%s">', $text_tag, $style_attr); ?>
                <?php echo nl2br(esc_html($text)); ?>
            <?php printf('</%s>', $text_tag); ?>
            
            <a href="<?php echo esc_url($button_url); ?>" class="tabi-popup-button"><?php echo esc_html($button); ?></a>
        </div>
    </div>
</div>
