jQuery(document).ready(function($) {
    // Initialize the WordPress color picker
    $('.tabi-color-picker').wpColorPicker({
        change: function(event, ui) {
            // Trigger change event on the input so our preview updater catches it
            $(event.target).val(ui.color.toString()).trigger('change');
        },
        clear: function() {
            $(this).prev('.wp-color-picker').val('').trigger('change');
        }
    });

    // --- Logic for Toggling Trigger Fields ---

    function toggleTriggerFields() {
        var selectedTrigger = $('input[name="popup_trigger_type"]:checked').val();

        if (selectedTrigger === 'scroll') {
            $('#tabi-scroll-trigger-row').show();
            $('#tabi-delay-trigger-row').hide();
        } else if (selectedTrigger === 'delay') {
            $('#tabi-scroll-trigger-row').hide();
            $('#tabi-delay-trigger-row').show();
        }
    }

    // Run on page load to set the initial state
    toggleTriggerFields();

    // Run when the radio button selection changes
    $('input[name="popup_trigger_type"]').on('change', toggleTriggerFields);

    // --- Live Preview Logic ---

    function updatePreview() {
        // Get values
        var text = $('textarea[name="popup_text"]').val();
        var btnText = $('input[name="popup_button"]').val();
        var bgColor = $('input[name="popup_bg_color"]').val();
        var position = $('input[name="popup_position"]:checked').val();
        var width = $('input[name="popup_width"]:checked').val();
        
        var textTag = $('select[name="popup_text_tag"]').val();
        var fontFamily = $('select[name="popup_font_family"]').val();
        var fontSize = $('input[name="popup_font_size"]').val();
        var fontStyle = $('select[name="popup_font_style"]').val();
        var fontColor = $('input[name="popup_font_color"]').val();

        // Update Text
        // Convert newlines to <br> for preview
        var formattedText = text.replace(/\n/g, '<br>');
        
        // Build the HTML tag for text
        var styleString = 'color:' + fontColor + '; font-family:' + fontFamily + '; font-size:' + fontSize + 'px; font-style:' + fontStyle + ';';
        var textHtml = '<' + textTag + ' style="' + styleString + '">' + formattedText + '</' + textTag + '>';
        
        $('#preview-text-container').html(textHtml);

        // Update Button
        $('#preview-button').text(btnText);

        // Update Background Color
        $('#preview-content').css('background-color', bgColor);

        // Update Position Class
        var $overlay = $('#preview-overlay');
        $overlay.removeClass('tabi-popup-center tabi-popup-bottom');
        if (position === 'bottom') {
            $overlay.addClass('tabi-popup-bottom');
        } else {
            $overlay.addClass('tabi-popup-center');
        }

        // Update Width Class
        var $content = $('#preview-content');
        $content.removeClass('tabi-popup-full');
        if (width === 'full') {
            $content.addClass('tabi-popup-full');
        }
    }

    // Bind events to inputs for real-time updates
    $('textarea[name="popup_text"], input[name="popup_button"], input[name="popup_font_size"]').on('input', updatePreview);
    
    $('select[name="popup_text_tag"], select[name="popup_font_family"], select[name="popup_font_style"]').on('change', updatePreview);
    
    $('input[name="popup_position"], input[name="popup_width"]').on('change', updatePreview);

    // Color pickers trigger 'change' via the wpColorPicker callback above
    $('input[name="popup_bg_color"], input[name="popup_font_color"]').on('change', updatePreview);

    // Initial update
    updatePreview();
    
    // Force active class on preview overlay to make content visible
    $('#preview-overlay').addClass('active');

    // --- Mobile Preview Toggle ---
    $('#tabi-preview-mobile').on('click', function() {
        $('#tabi-popup-preview-wrapper').addClass('mobile-view');
        $(this).addClass('active');
        $('#tabi-preview-desktop').removeClass('active');
    });

    $('#tabi-preview-desktop').on('click', function() {
        $('#tabi-popup-preview-wrapper').removeClass('mobile-view');
        $(this).addClass('active');
        $('#tabi-preview-mobile').removeClass('active');
    });
});