<?php
/**
 * Plugin Name: Tabi Plugins by Franklyn
 * Description: Custom button, Elementor swiper and popup.
 * Version: 1.0
 * Author: Gabriely Muniz and Felipe Coutinho
 */

if (!defined('ABSPATH')) exit;

function tabi_should_show_popup() {
    $enabled = get_option('tabi_popup_enabled');
    if ( ! $enabled ) {
        return false;
    }

    $pages = get_option('tabi_popup_pages', '');
    if ( empty( $pages ) ) {
        return true;
    }

    $page_ids = array_map( 'intval', explode( ',', $pages ) );
    return in_array( get_queried_object_id(), $page_ids );
}

function tabi_enqueue_assets() {
    wp_enqueue_style(
        'tabi-buttons',
        plugin_dir_url(__FILE__) . 'css/buttons.css'
    );

    wp_enqueue_style(
        'tabi-swiper',
        plugin_dir_url(__FILE__) . 'css/swipper.css'
    );

    $show = tabi_should_show_popup();

    if ( $show ) {
        wp_enqueue_style(
            'tabi-typekit',
            'https://use.typekit.net/jtf2xza.css',
            array(),
            null
        );

        wp_enqueue_style(
            'tabi-popup',
            plugin_dir_url(__FILE__) . 'css/popup.css'
        );

        wp_enqueue_script(
            'tabi-popup-js',
            plugin_dir_url(__FILE__) . 'js/popup.js',
            array('jquery'),
            '1.0',
            true
        );

        $scroll = get_option('tabi_popup_scroll', 80);
        $delay = get_option('tabi_popup_delay', 3);
        $trigger = get_option('tabi_popup_trigger_type', 'scroll');
        wp_localize_script('tabi-popup-js', 'tabiSettings', array(
            'scrollPoint' => $scroll,
            'delay'       => $delay * 1000,
            'triggerType' => $trigger,
            'ajaxUrl'     => admin_url('admin-ajax.php'),
            'nonce'       => wp_create_nonce('tabi_track_view_nonce')
        ));
    }
}
add_action('wp_enqueue_scripts', 'tabi_enqueue_assets');

function tabi_render_popup() {
    $show = tabi_should_show_popup();

    if ( $show ) {
        include plugin_dir_path(__FILE__) . 'templates/popup.php';
    }
}
add_action('wp_footer', 'tabi_render_popup');

function tabi_enqueue_admin_scripts($hook_suffix) {
    // Only load on our specific admin page
    if ($hook_suffix !== 'toplevel_page_tabi-popup-settings') {
        return;
    }
    // Enqueue WordPress's built-in color picker
    wp_enqueue_style('wp-color-picker');
    
    // Enqueue Popup CSS for the preview
    wp_enqueue_style(
        'tabi-popup-preview-css',
        plugin_dir_url(__FILE__) . 'css/popup.css'
    );
    
    // Enqueue Typekit for the preview
    wp_enqueue_style(
        'tabi-typekit',
        'https://use.typekit.net/jtf2xza.css'
    );

    wp_enqueue_script(
        'tabi-admin-js',
        plugin_dir_url(__FILE__) . 'js/admin.js',
        array('wp-color-picker', 'jquery'), false, true
    );
}
add_action('admin_enqueue_scripts', 'tabi_enqueue_admin_scripts');

function tabi_admin_menu() {
    add_menu_page(
        'Popup Settings',
        'Popup Settings',
        'manage_options',
        'tabi-popup-settings',
        'tabi_settings_page',
        'dashicons-megaphone',
        20
    );
}
add_action('admin_menu', 'tabi_admin_menu');

function tabi_settings_page() {
    if ( isset( $_POST['tabi_save'] ) ) {
        if ( ! isset( $_POST['tabi_popup_nonce'] ) || ! wp_verify_nonce( $_POST['tabi_popup_nonce'], 'tabi_save_action' ) ) {
            echo '<div class="error"><p>Security check failed.</p></div>';
        } else {
            update_option('tabi_popup_enabled', isset($_POST['popup_enabled']) ? 1 : 0);
            update_option('tabi_popup_text', isset($_POST['popup_text']) ? sanitize_textarea_field($_POST['popup_text']) : '');
            update_option('tabi_popup_button', isset($_POST['popup_button']) ? sanitize_text_field($_POST['popup_button']) : '');
            update_option('tabi_popup_button_url', isset($_POST['popup_button_url']) ? sanitize_url($_POST['popup_button_url']) : '');
            update_option('tabi_popup_pages', isset($_POST['popup_pages']) ? sanitize_text_field($_POST['popup_pages']) : '');
            update_option('tabi_popup_bg_color', isset($_POST['popup_bg_color']) ? sanitize_hex_color($_POST['popup_bg_color']) : '');
            update_option('tabi_popup_scroll', isset($_POST['popup_scroll']) ? intval($_POST['popup_scroll']) : 80);
            update_option('tabi_popup_delay', isset($_POST['popup_delay']) ? intval($_POST['popup_delay']) : 3);
            update_option('tabi_popup_trigger_type', isset($_POST['popup_trigger_type']) ? sanitize_key($_POST['popup_trigger_type']) : 'scroll');
            update_option('tabi_popup_position', isset($_POST['popup_position']) ? sanitize_key($_POST['popup_position']) : 'center');
            update_option('tabi_popup_width', isset($_POST['popup_width']) ? sanitize_key($_POST['popup_width']) : 'default');
            update_option('tabi_popup_font_color', isset($_POST['popup_font_color']) ? sanitize_hex_color($_POST['popup_font_color']) : '#000000');
            update_option('tabi_popup_font_family', isset($_POST['popup_font_family']) ? sanitize_text_field($_POST['popup_font_family']) : 'sans-serif');
            update_option('tabi_popup_text_tag', isset($_POST['popup_text_tag']) ? sanitize_key($_POST['popup_text_tag']) : 'p');
            update_option('tabi_popup_font_size', isset($_POST['popup_font_size']) ? intval($_POST['popup_font_size']) : 16);
            update_option('tabi_popup_font_style', isset($_POST['popup_font_style']) ? sanitize_key($_POST['popup_font_style']) : 'normal');
            
            echo '<div class="updated"><p>Settings saved successfully!</p></div>';
        }
    }

    $enabled = get_option('tabi_popup_enabled', 0);
    $text    = get_option('tabi_popup_text', 'Your popup text');
    $button  = get_option('tabi_popup_button', 'Click here');
    $button_url = get_option('tabi_popup_button_url', '#');
    $pages   = get_option('tabi_popup_pages', '');
    $bg_color = get_option('tabi_popup_bg_color', '#b8a999');
    $scroll  = get_option('tabi_popup_scroll', 80);
    $delay   = get_option('tabi_popup_delay', 3);
    $trigger = get_option('tabi_popup_trigger_type', 'scroll');
    $position = get_option('tabi_popup_position', 'center');
    $width    = get_option('tabi_popup_width', 'default');
    $font_color = get_option('tabi_popup_font_color', '#000000');
    $font_family = get_option('tabi_popup_font_family', 'sans-serif');
    $text_tag = get_option('tabi_popup_text_tag', 'p');
    $font_size = get_option('tabi_popup_font_size', 16);
    $font_style = get_option('tabi_popup_font_style', 'normal');
    ?>
    <style>
        .tabi-settings-card {
            background: #fff;
            border: 1px solid #ccd0d4;
            box-shadow: 0 1px 3px rgba(0,0,0,.04);
            padding: 20px 30px;
            max-width: 800px;
            margin-top: 20px;
            border-radius: 4px;
        }
        .tabi-section-title {
            font-size: 1.3em;
            margin: 0 0 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
            color: #1d2327;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .tabi-section-title .dashicons {
            font-size: 24px;
            width: 24px;
            height: 24px;
            color: #2271b1;
        }
        .tabi-form-section {
            margin-bottom: 40px;
        }
        .tabi-color-picker-wrap {
            padding-top: 5px;
        }
        /* Preview Styles */
        .tabi-preview-container {
            margin-top: 30px;
            padding: 20px;
            background: #f0f0f1;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
        }
        .tabi-preview-title {
            font-size: 1.2em;
            margin-bottom: 15px;
            font-weight: 600;
        }
        #tabi-popup-preview-wrapper {
            position: relative;
            min-height: 300px;
            background: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgdmlld0JveD0iMCAwIDIwIDIwIiBmaWxsPSJub25lIiBzdHJva2U9IiNlNWU1ZTUiIHN0cm9rZS13aWR0aD0iMSI+PHBhdGggZD0iTTAgMGgyMHYyMEgwVjB6Ii8+PC9zdmc+') repeat;
            border: 1px solid #ddd;
            display: flex;
            overflow: hidden;
            transition: width 0.3s ease, border-radius 0.3s ease, height 0.3s ease;
            margin: 0 auto;
            width: 100%;
        }
        .tabi-preview-controls {
            margin-bottom: 15px;
            display: flex;
            gap: 5px;
        }
        .tabi-preview-controls .button.active {
            background: #2271b1;
            color: #fff;
            border-color: #2271b1;
        }
        #tabi-popup-preview-wrapper.mobile-view {
            width: 375px;
            height: 600px;
            border: 8px solid #333;
            border-radius: 24px;
        }
        /* Override popup overlay for preview to stay inside the box */
        #tabi-popup-preview-wrapper .tabi-popup-overlay {
            position: absolute;
            opacity: 1;
            visibility: visible;
            z-index: 10;
        }
        /* Footer Styles */
        .tabi-admin-footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ccd0d4;
            text-align: center;
            color: #646970;
            font-size: 13px;
        }
        .tabi-admin-footer a {
            color: #2271b1;
            text-decoration: none;
        }
        .tabi-admin-footer a:hover {
            text-decoration: underline;
        }
    </style>

    <div class="wrap">
        <h1 class="wp-heading-inline">Tabi Popup Settings</h1>
        
        <form method="post">
            <?php wp_nonce_field('tabi_save_action', 'tabi_popup_nonce'); ?>
            
            <div class="tabi-settings-card">
                <!-- Display Section -->
                <div class="tabi-form-section">
                    <h2 class="tabi-section-title"><span class="dashicons dashicons-visibility"></span> Display and Control</h2>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row">Enable Popup</th>
                            <td>
                                <label for="popup_enabled">
                                    <input type="checkbox" id="popup_enabled" name="popup_enabled" value="1" <?php checked($enabled, 1); ?>>
                                    Show popup on site
                                </label>
                                <p class="description">Enables or disables the popup display for visitors.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Page IDs (Optional)</th>
                            <td>
                                <input type="text" name="popup_pages" value="<?php echo esc_attr($pages); ?>" class="regular-text" placeholder="Ex: 10, 25">
                                <p class="description">Enter page IDs separated by commas (e.g., 10, 25). Leave blank to show on <strong>all pages</strong>.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Popup Position</th>
                            <td>
                                <fieldset>
                                    <label><input type="radio" name="popup_position" value="center" <?php checked($position, 'center'); ?>> Center of Screen</label><br>
                                    <label><input type="radio" name="popup_position" value="bottom" <?php checked($position, 'bottom'); ?>> Bottom of Screen</label>
                                </fieldset>
                                <p class="description">Choose where the popup should appear.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Popup Width</th>
                            <td>
                                <fieldset>
                                    <label><input type="radio" name="popup_width" value="default" <?php checked($width, 'default'); ?>> Default (Compact)</label><br>
                                    <label><input type="radio" name="popup_width" value="full" <?php checked($width, 'full'); ?>> Full Width (100%)</label>
                                </fieldset>
                                <p class="description">Choose if the popup should be compact or span the full width of the screen.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Trigger Type</th>
                            <td>
                                <fieldset>
                                    <label><input type="radio" name="popup_trigger_type" value="scroll" <?php checked($trigger, 'scroll'); ?>> Scroll Percentage</label><br>
                                    <label><input type="radio" name="popup_trigger_type" value="delay" <?php checked($trigger, 'delay'); ?>> Time Delay</label>
                                </fieldset>
                                <p class="description">Choose how the popup should be triggered.</p>
                            </td>
                        </tr>
                        <tr id="tabi-scroll-trigger-row">
                            <th scope="row">Scroll Trigger (%)</th>
                            <td>
                                <input type="number" name="popup_scroll" value="<?php echo esc_attr($scroll); ?>" class="small-text" min="0" max="100">
                                <p class="description">Used if Trigger Type is set to <strong>Scroll Percentage</strong>.</p>
                            </td>
                        </tr>
                        <tr id="tabi-delay-trigger-row">
                            <th scope="row">Delay (seconds)</th>
                            <td>
                                <input type="number" name="popup_delay" value="<?php echo esc_attr($delay); ?>" class="small-text" min="0">
                                <p class="description">Used if Trigger Type is set to <strong>Time Delay</strong>.</p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Content Section -->
                <div class="tabi-form-section" style="margin-bottom: 0;">
                    <h2 class="tabi-section-title"><span class="dashicons dashicons-edit"></span> Content and Style</h2>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row">Popup Text</th>
                            <td>
                                <textarea name="popup_text" class="large-text" rows="4"><?php echo esc_textarea($text); ?></textarea>
                                <p class="description">Enter the main message for the popup. Line breaks are allowed.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Text Tag & Family</th>
                            <td>
                                <select name="popup_text_tag" style="vertical-align: middle;">
                                    <option value="p" <?php selected($text_tag, 'p'); ?>>Paragraph (p)</option>
                                    <option value="h1" <?php selected($text_tag, 'h1'); ?>>Heading 1 (h1)</option>
                                    <option value="h2" <?php selected($text_tag, 'h2'); ?>>Heading 2 (h2)</option>
                                    <option value="h3" <?php selected($text_tag, 'h3'); ?>>Heading 3 (h3)</option>
                                </select>
                                <select name="popup_font_family" style="vertical-align: middle;">
                                    <option value="sans-serif" <?php selected($font_family, 'sans-serif'); ?>>System Default (Sans-Serif)</option>
                                    <option value="serif" <?php selected($font_family, 'serif'); ?>>System Default (Serif)</option>
                                    <option value="Arial, Helvetica, sans-serif" <?php selected($font_family, 'Arial, Helvetica, sans-serif'); ?>>Arial</option>
                                    <option value="'Times New Roman', Times, serif" <?php selected($font_family, "'Times New Roman', Times, serif"); ?>>Times New Roman</option>
                                    <option value="Georgia, serif" <?php selected($font_family, 'Georgia, serif'); ?>>Georgia</option>
                                    <option value="Verdana, Geneva, sans-serif" <?php selected($font_family, 'Verdana, Geneva, sans-serif'); ?>>Verdana</option>
                                    <option value="'futura-pt', sans-serif" <?php selected($font_family, "'futura-pt', sans-serif"); ?>>Futura PT</option>
                                </select>
                                <p class="description">Choose the HTML tag and font family for the main text.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Text Style</th>
                            <td>
                                <div style="display: flex; align-items: center; gap: 15px;">
                                    <div>
                                        <input type="number" name="popup_font_size" value="<?php echo esc_attr($font_size); ?>" class="small-text" min="1">
                                        <label>Font Size (px)</label>
                                    </div>
                                    <div>
                                        <select name="popup_font_style">
                                            <option value="normal" <?php selected($font_style, 'normal'); ?>>Normal</option>
                                            <option value="italic" <?php selected($font_style, 'italic'); ?>>Italic</option>
                                        </select>
                                        <label>Font Style</label>
                                    </div>
                                    <div>
                                        <input type="text" name="popup_font_color" value="<?php echo esc_attr($font_color); ?>" class="tabi-color-picker">
                                        <label>Font Color</label>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Action Button</th>
                            <td>
                                <input type="text" name="popup_button" value="<?php echo esc_attr($button); ?>" class="regular-text" placeholder="Button text">
                                <br><br>
                                <input type="url" name="popup_button_url" value="<?php echo esc_attr($button_url); ?>" class="regular-text" placeholder="https://...">
                                <p class="description">Define the button label (e.g., "Learn More") and the destination URL.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Background Color</th>
                            <td class="tabi-color-picker-wrap">
                                <input type="text" name="popup_bg_color" value="<?php echo esc_attr($bg_color); ?>" class="tabi-color-picker">
                                <p class="description">Choose the background color for the popup window.</p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <!-- Preview Section -->
            <div class="tabi-preview-container">
                <div class="tabi-preview-title">Live Preview</div>
                <div class="tabi-preview-controls">
                    <button type="button" class="button active" id="tabi-preview-desktop"><span class="dashicons dashicons-desktop"></span> Desktop</button>
                    <button type="button" class="button" id="tabi-preview-mobile"><span class="dashicons dashicons-smartphone"></span> Mobile</button>
                </div>
                <div id="tabi-popup-preview-wrapper">
                    <div id="preview-overlay" class="tabi-popup-overlay tabi-popup-center">
                        <div id="preview-content" class="tabi-popup-content" style="background-color: <?php echo esc_attr($bg_color); ?>;">
                            <span class="tabi-popup-close">&times;</span>
                            <div class="tabi-popup-body">
                                <div id="preview-text-container"></div>
                                <a href="#" id="preview-button" class="tabi-popup-button" onclick="return false;"><?php echo esc_html($button); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <p class="submit" style="padding-left: 0;">
                <input type="submit" name="tabi_save" class="button button-primary button-large" value="Save Changes">
            </p>
        </form>

        <div class="tabi-admin-footer">
            <p>Developed by <a href="#" target="_blank">Tabi</a> & <a href="#" target="_blank">Franklyn Agency</a>.</p>
        </div>
    </div>
    <?php
}

/* --- View Tracking & Dashboard Widget --- */

function tabi_track_popup_view() {
    check_ajax_referer('tabi_track_view_nonce', 'nonce');
    
    $views = get_option('tabi_popup_views', 0);
    $views++;
    update_option('tabi_popup_views', $views);
    
    wp_send_json_success();
}
add_action('wp_ajax_tabi_track_view', 'tabi_track_popup_view');
add_action('wp_ajax_nopriv_tabi_track_view', 'tabi_track_popup_view');

function tabi_add_dashboard_widgets() {
    wp_add_dashboard_widget(
        'tabi_popup_views_widget',
        'Tabi Popup Views',
        'tabi_dashboard_widget_content'
    );
}
add_action('wp_dashboard_setup', 'tabi_add_dashboard_widgets');

function tabi_dashboard_widget_content() {
    $views = get_option('tabi_popup_views', 0);
    echo '<div class="tabi-dashboard-widget" style="text-align: center; padding: 20px;">';
    echo '<div class="dashicons dashicons-visibility" style="font-size: 40px; width: 40px; height: 40px; color: #2271b1; margin-bottom: 10px;"></div>';
    echo '<h3 style="font-size: 36px; margin: 0; color: #1d2327; line-height: 1;">' . number_format($views) . '</h3>';
    echo '<p style="margin-top: 10px; color: #646970; font-size: 14px;">Total Popup Impressions</p>';
    echo '</div>';
}